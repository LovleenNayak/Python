#!C:\Users\91876\Anaconda3\python.exe

import cgi, cgitb
cgitb.enable()

print("Content-type:text/html\r\n\r\n")
print('<html>')
print('<body>')
print('<center><h2 style="color:red">This is the profile page</h2></center>')
print('</body>')
print('</html>')